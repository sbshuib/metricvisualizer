import MetricsVisualizer from '../components/MetricsVisualizer';

export default function HomePage() {
  return <MetricsVisualizer />;
}